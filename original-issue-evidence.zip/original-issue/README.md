# 单独剪贴色相/饱和度的 RGB 与 Photoshop 不一致

类型：Bug。状态：待提交。修复负责人：PhotoCraft 引擎维护者，未分配。回归负责人：测试维护者，未分配。

单独剪贴色相/饱和度在本轮参考核验有效后记录 `FAIL / PIXEL_MISMATCH`，Alpha 完全一致。目标是让下列配置与 Photoshop 严格逐像素一致。

## 实际结果与预期

可搜索错误：`image-1-hs: FAIL (PIXEL_MISMATCH)`。

本轮观察时间为 2026-10-23 16:17:41 至 16:19:14（北京时间），使用 1662×1026 的新飞机图。以下数值取自各项原始 `evidence.comparison.full`，每幅画布有 1,705,212 个像素。

| 用例 | RGB 差异像素 | 占全画布比例 | R / G / B 最大差值 | Alpha 差异像素 | 原始结果 |
| --- | ---: | ---: | --- | ---: | --- |
| image-1-hs | 1,403,264 | 82.292642% | 2 / 3 / 2 | 0 | [case.json](evid/cases/image-1-hs/case.json) |

| 用例 | 通道 | 最大绝对差 | MAE | P99 |
| --- | --- | ---: | ---: | ---: |
| image-1-hs | R | 2 | 0.5750358313218532 | 2 |
| image-1-hs | G | 3 | 0.637641536653507 | 2 |
| image-1-hs | B | 2 | 0.2788755884898769 | 1 |

预期依据：[严格像素判定](evid/source-code/TESTING.md)要求全画布 Alpha 一致，任一侧非透明处的 RGB 逐通道一致。实现见 [comparePixels](evid/source-code/src/pixels.ts)。参数回读容差不用于像素判定。

各项均为 `verificationLevel: full`，通过源图导入校验、Photoshop pixmap 与正式 PNG 自检及双方颜色上下文核验。调节层确实改变了 Photoshop 像素，证据字段为 `sourceImport`、`psSelfCheck`、`color` 和 `psInfluence`。

## 配置与图片证据

图层应用顺序从图片向上记录。所有调节层均剪贴到 `parity-base`，图片图层无图片遮罩。

| 用例 | 顺序与参数 | 完整配置 |
| --- | --- | --- |
| image-1-hs | 色相/饱和度：hue=-158，saturation=20，lightness=20，colorize=false，六个单独色彩范围均为零 | [fixture.json](evid/cases/image-1-hs/fixture.json) |

### image-1-hs

[同一输入 PSD](evid/cases/image-1-hs/input.psd) · [完整原始结果](evid/cases/image-1-hs/case.json)

| Photoshop | PhotoCraft |
| --- | --- |
| ![Photoshop image-1-hs](evid/cases/image-1-hs/ps-export.png) | ![PhotoCraft image-1-hs](evid/cases/image-1-hs/photocraft-export.png) |

| RGB 差异图 | Alpha 差异图 |
| --- | --- |
| ![RGB difference image-1-hs](evid/cases/image-1-hs/rgb-diff.png) | ![Alpha difference image-1-hs](evid/cases/image-1-hs/alpha-diff.png) |

## 环境与来源

[manifest.json](evid/manifest.json)、[workflow.json](evid/workflow/workflow.json)和[构建证明](evid/engine-build-info.json)记录实际执行来源。

| 项目 | 本轮值 |
| --- | --- |
| 系统 | Windows x64 |
| Photoshop | 26.11.6 |
| PhotoCraft | 0.14.0 |
| 引擎提交 | `ff4738810134d7f7e68b49f2e4f231b686282ff3` |
| Node / pnpm | 22.23.4 / 11.5.0 |
| Bridge SDK / Generator | 3.0.2 / 3.0.2 |
| Vitest / generator-core | 2.1.9 / 3.12.1 |
| 运行编号 | `2026-10-23T08-18-03-286Z-9a75f2e3` |
| Seed / 生成器版本 | `d1a4949fa9a1b6db3d04f5c7f2b2e423` / 1 |

源素材为 [source/1.png](evid/source/1.png)，1662×1026、RGB/8、1,340,426 字节。SHA-256：`05ccc491836db48c06886f01e21b175b2be85fac170580825bd2616b33c48e41`。测试文档使用 sRGB，源 PNG 保持原始字节。

本轮工作区含未提交实现，仅检出记录的 Git 提交不足以复现。[source-code/](evid/source-code/)保存 manifest 中 47 个相关源码与配置文件的原始快照；[证据清单](evid/evidence-index.json)记录每个文件的来源、字节数与 SHA-256。

## 复现

以下命令按本轮已执行的官方入口整理。本次证据归档没有再次运行 Photoshop。

1. 复现者在测试仓库根目录核对 Node 22、pnpm 11.5.0 和已准备的 Photoshop / Bridge core，环境要求见 [TESTING.md 快照](evid/source-code/TESTING.md)。
2. 复现者准备与构建证明匹配的 PhotoCraft CLI，并设置 `PHOTOCRAFT_CLI` 和 `PS_BRIDGE_PARITY_ENGINE_SOURCE`。
3. 复现者使用包内源图和相同 seed 运行整个图片组合模块：

```powershell
$issueRoot = (Resolve-Path -LiteralPath '.notes/issues/hue-saturation-rgb-mismatch').Path
$env:PS_BRIDGE_PARITY_INPUT_ROOT = Join-Path $issueRoot 'evid/source'
$env:PS_BRIDGE_PARITY_OUTPUT_ROOT = Join-Path $env:TEMP ('photocraft-issue-replay-' + [guid]::NewGuid().ToString('N'))
$env:PS_BRIDGE_PARITY_SEED = 'd1a4949fa9a1b6db3d04f5c7f2b2e423'
$portProbe = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, 0)
$portProbe.Start()
$replayPort = $portProbe.LocalEndpoint.Port
$portProbe.Stop()
pnpm exec ps-generator-bridge test tests/image-compositing --port $replayPort
```

4. 复现者在新运行中按 `image-1-hs` 定位结果，并与本包 fixture.json、case.json 和图像核对。

该入口会运行模块全部 6 项，不提供本次未验证的单项筛选承诺。若独立移出 issue 文件夹，复现者将 `$issueRoot` 改为该文件夹实际路径。依赖、Photoshop 和引擎二进制由复现环境提供。

已有 PSD 可直接从本 issue 的 `evid/cases/<caseId>/input.psd` 读取。原始 case.json 的 `commands` 保存 PhotoCraft JSON Lines 请求；重放时将历史 `work/` 输入路径换成包内持久 PSD，将导出路径换成新的输出目录。

## 验收条件与待办

- [ ] 本 issue 的 1 项配置在修复版本记录 PASS，`rgbPixels=0` 且 `alphaPixels=0`。
- [ ] 源图导入、图层顺序、剪贴关系、调节参数、颜色上下文和 Photoshop 参考自检继续通过。
- [ ] 调节层继续产生经核验的像素影响，原图及遮罩对照保持通过。
- [ ] 修复版本保留构建来源、新的逐项图像、比较结果和成功清理记录。

覆盖一个全局色相/饱和度调节层，着色关闭，六个单独色彩范围保持零。亮度/对比度及双层叠加由其它症状条目跟踪。

根因尚未定位；本轮没有证实算法、PSD 映射或量化中的具体故障。引擎维护者（未分配）负责定位与修复，测试维护者（未分配）负责回归和证据。正式 runner 目前固定官方版本来源，验证修复构建时由测试维护者明确更新来源约束及构建证明。

## 附件使用

提交 issue 时复制本 README，并携带整个 `evid/`。主要图片已在上方内嵌，持久 PSD、原始 pixmap、ICC、调节前后 PNG、参数与命令记录均在包内。证据目录及校验方法见 [evid/README.md](evid/README.md)。

本 issue 所需证据不依赖原始 output 目录或其它 issue 文件夹。全轮 summary.json 保留 6 项原始记录，本包只携带本 issue 的业务用例及三项公共校准；其它业务条目不代表本包附带了对应附件。
