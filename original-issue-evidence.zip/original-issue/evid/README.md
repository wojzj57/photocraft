# 单独剪贴色相/饱和度证据目录

本目录独立保存本 issue 的 1 项业务用例和三项内部校准。复制文件保持原始字节，路径映射与 SHA-256 见 [evidence-index.json](evidence-index.json)。

| 路径 | 内容 |
| --- | --- |
| [source/1.png](source/1.png) | 原始非涉密飞机图 |
| cases/ | image-1-hs 的全部 artifacts、case.json、fixture.json 与持久 PSD |
| calibration/ | 三项 PASS 校准的原始 JSON 和图像 |
| [manifest.json](manifest.json) | 实际 Host、引擎、输入和工作区来源 |
| [summary.json](summary.json) | 全轮原始机器汇总：2 PASS、4 FAIL、0 NOT_EXECUTED |
| [summary.md](summary.md) | 原始运行初始总结，保持原字节 |
| [engine-build-info.json](engine-build-info.json) | 引擎构建记录，摘要与 manifest.engine.buildInfoSha256 相同 |
| [workflow/workflow.json](workflow/workflow.json) | 本轮各阶段退出状态和时间 |
| [workflow/report.json](workflow/report.json) | 全轮静态报告元数据快照 |
| [workflow/logs/live.txt](workflow/logs/live.txt) | 原始真机日志，字节保持不变，仅后缀由 .log 改为 .txt |
| [workflow/logs/typecheck.txt](workflow/logs/typecheck.txt)、[build.txt](workflow/logs/build.txt)、[offline.txt](workflow/logs/offline.txt) | 本轮准备检查日志 |
| source-code/ | 与 manifest 对应的 47 个源码与配置文件快照 |
| [validation.json](validation.json) | 本次归档的摘要、图片解码、PSD 头、覆盖范围和文档引用校验结果 |

## 定位证据

- image-1-hs：[原始结果](cases/image-1-hs/case.json)、[参数](cases/image-1-hs/fixture.json)、[PSD](cases/image-1-hs/input.psd)、[Photoshop PNG](cases/image-1-hs/ps-export.png)、[PhotoCraft PNG](cases/image-1-hs/photocraft-export.png)、[RGB 差异图](cases/image-1-hs/rgb-diff.png)、[Alpha 差异图](cases/image-1-hs/alpha-diff.png)。

`cases/` 与 `calibration/` 保留 artifacts 中相对于运行根目录的路径，因此相关 case.json 的每个 artifact 均可在本目录找到。全轮 summary.json 及 report.json 还列出未打包的其它业务用例，适用范围以 evidence-index.json.includedCaseIds 为准。

原始 JSON 中的绝对路径是当时的执行记录，历史 work 目录已清理。复现使用本地持久 PSD，并为新输出选择独立目录，不覆盖包内证据。source-code 仅为来源快照，安装与执行使用完整测试仓库及外部依赖。

## 校验摘要

从 issue 文件夹运行以下只读命令。它逐项检查全部原始复制文件，无需 Photoshop：

```powershell
$index = Get-Content -Raw -Encoding utf8 -LiteralPath 'evid/evidence-index.json' | ConvertFrom-Json
foreach ($file in $index.immutableCopies) {
  $target = Join-Path 'evid' $file.path
  $item = Get-Item -LiteralPath $target
  $actualHash = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($item.Length -ne $file.bytes -or $actualHash -ne $file.sha256) { throw ('Evidence mismatch: ' + $file.path) }
}
```

包内验证记录只证明归档完整性，不是新增真机运行或产品通过。
