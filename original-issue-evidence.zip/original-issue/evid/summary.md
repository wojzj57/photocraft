# PhotoCraft / Photoshop render parity

Run: 2026-10-23T08-18-03-286Z-9a75f2e3

Status: FAIL; executed 6/6; declarations 6.

PASS 2; FAIL 4; NOT_EXECUTED 0.

Test execution and pixel agreement are separate results. A compatibility failure is preserved.

| Case | Status | Reasons |
| --- | --- | --- |
| [image-1-plain](cases/image-1-plain/case.json) | PASS |  |
| [image-1-mask](cases/image-1-mask/case.json) | PASS |  |
| [image-1-bc](cases/image-1-bc/case.json) | FAIL | PIXEL_MISMATCH |
| [image-1-hs](cases/image-1-hs/case.json) | FAIL | PIXEL_MISMATCH |
| [image-1-bc-hs](cases/image-1-bc-hs/case.json) | FAIL | PIXEL_MISMATCH |
| [image-1-hs-bc](cases/image-1-hs-bc/case.json) | FAIL | PIXEL_MISMATCH |

Run errors: none
