# Hue/Saturation RGB/8 fix: review evidence

This package combines the supplied original issue evidence with the independently verified fixed results for commit `352339e4ebe19530ea386e99d047dbd689dd2e50`.

| Measurement | Archived PhotoCraft 0.14.0 | Fixed branch CLI |
| --- | ---: | ---: |
| Visible RGB mismatch pixels | 1,403,264 / 1,705,212 | 0 / 1,705,212 |
| Maximum channel difference | 3 | 0 |
| Alpha mismatch pixels | 0 | 0 |

The same PSD and pixel-identical Photoshop reference were used. PNG encoding and metadata can differ while decoded RGBA pixels remain identical. Settings: Hue -158, Saturation +20, Lightness +20, Colorize off, neutral color ranges, RGB/8; Photoshop 26.11.6.

- `original-issue/` contains every file present in the supplied issue directory, including the source PNG, PSD, raw pixmap, ICC capture, controls, original results and historical notes. Historical links to files not present in that directory remain historical references.
- `fixed-validation/photoshop-core/` contains per-case readback, comparison JSON and original PNG bytes for all 12 required live cases. The original PSD is stored once at `original-issue/evid/cases/image-1-hs/input.psd`; synthetic inputs can be regenerated with the committed live tests.
- `fixed-validation/final-validation.json` and logs record all checks, including the independently reproduced baseline GPU timing and layout-benchmark setup failures. Those two failures remain; full repository validation is not green. `fixed-validation/baseline/` contains their baseline proof. References to a prior validation directory in the report map to this baseline directory.
- `fixed-validation/docstrings.json` is a local syntax inventory, not a remote CodeRabbit result: 54/64 named routines when named property stubs are included; 50 anonymous callbacks excluded.
- The preserved CLI binary is not distributed here; its SHA-256 and build receipt are included. Validation preceded a commit-preflight removal of one redundant final newline from a JavaScript test helper; see `fixed-validation/formatting-receipt.json`. Production source was unchanged.

For public sharing, text copies have local filesystem paths and email addresses redacted; user document-state listings are replaced with a restoration result. Binary evidence is byte-for-byte unchanged. `attachment-manifest.json` records both original and published SHA-256 hashes, so historical manifests can be distinguished from this publication's hashes. This package does not alter the source issue directory.

To reproduce, build this commit's `photocraft-cli` and follow `tests/photoshop-live/README.md`. Point `PHOTOCRAFT_HS_ISSUE_ROOT` to the extracted `original-issue` directory and set `PHOTOCRAFT_CLI` to the rebuilt executable. Select the required cases with `PHOTOCRAFT_HS_CASES` if running the complete 12-case suite.
