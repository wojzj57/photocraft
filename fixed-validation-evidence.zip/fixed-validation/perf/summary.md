## Performance (quick run)

- Machine: Intel64 Family 6 Model 198 Stepping 2, GenuineIntel (24 cores, ?), GPU NVIDIA GeForce RTX 5080, Microsoft Windows [Version 10.0.26100.6584] x86_64; class `windows-x86-64-intel64-family-6-model-198-stepping-2-genuineintel-nvidia-geforce-rtx-5080`
- Commit b0622d20cadd7e994a51ce2f48e415efbbdec24f (dirty), 2026-10-25T13:29:50Z
- Load average (1/5/15 min): n/a at start, n/a at end
- baseline is from machine class `macos-aarch64-apple-m4-pro-apple-m4-pro`, this is `windows-x86-64-intel64-family-6-model-198-stepping-2-genuineintel-nvidia-geforce-rtx-5080`: regression check skipped
- Quick mode: small documents, budgets not applied (they are set for full-size documents).
- Bench `bench_filters2`: ok, 1 s, load n/a
- Bench `bevel_bench`: ok, 7 s, load n/a
- Bench `camera_raw_bench`: ok, 4 s, load n/a
- Bench `layout_bench`: error, 12 s, load n/a: layout_bench  --json workspace\target/agent-fix\perf\layout_bench.json: exited with exit code: 101
- Bench `perf_scenarios`: ok, 27 s, load n/a
- Bench `type_bench`: ok, 3 s, load n/a

| Id | Scenario | Target | p50 ms | p95 ms | max ms | Peak RSS | GPU | vs baseline | Status | Issue |
|---|---|---|---:|---:|---:|---:|---:|---:|---|---|
| P1 | Move a layer with layer styles (per drag update) | ≤ 25 ms p95 | 3.89 | 22.6 | 22.6 | 279 MB | 75 MB | – | tracked | [#209](https://github.com/storytold/photocraft/issues/209) |
| P2 | Change layer opacity | ≤ 20 ms p95 | 1.56 | 2.00 | 2.00 | 282 MB | 75 MB | – | tracked | [#209](https://github.com/storytold/photocraft/issues/209) |
| P3 | Change layer fill | ≤ 20 ms p95 | 1.61 | 1.85 | 1.85 | 283 MB | 75 MB | – | tracked | [#209](https://github.com/storytold/photocraft/issues/209) |
| P4 | Change blend mode | ≤ 20 ms p95 | 1.39 | 1.56 | 1.56 | 283 MB | 75 MB | – | tracked | [#209](https://github.com/storytold/photocraft/issues/209) |
| P5 | Toggle visibility | ≤ 10 ms p95 | 2.01 | 16.6 | 16.6 | 283 MB | 75 MB | – | tracked | [#209](https://github.com/storytold/photocraft/issues/209) |
| P6 | Undo a move | ≤ 25 ms p95 | 2.86 | 17.9 | 17.9 | 284 MB | 75 MB | – | tracked | [#209](https://github.com/storytold/photocraft/issues/209) |
| P7 | Redo a property change | ≤ 25 ms p95 | 1.36 | 15.2 | 15.2 | 282 MB | 75 MB | – | tracked | [#209](https://github.com/storytold/photocraft/issues/209) |
| P8 | Duplicate a 12 MP layer (first) | ≤ 100 ms p95 | 4.53 | 25.7 | 25.7 | 317 MB | 167 MB | – | tracked | [#209](https://github.com/storytold/photocraft/issues/209) |
| P9 | Duplicate a 12 MP layer (repeat) | ≤ 20 ms p95 | 3.30 | 8.82 | 8.82 | 318 MB | 167 MB | – | tracked | [#209](https://github.com/storytold/photocraft/issues/209) |
| P10 | Paste a 12 MP layer (first) | ≤ 100 ms p95 | 4.05 | 4.48 | 4.48 | 344 MB | 227 MB | – | tracked | [#209](https://github.com/storytold/photocraft/issues/209) |
| P11 | Paste a 12 MP layer (repeat) | ≤ 20 ms p95 | 3.29 | 19.1 | 19.1 | 344 MB | 227 MB | – | tracked | [#209](https://github.com/storytold/photocraft/issues/209) |
| P12 | Arrow-key nudge in a 150-layer document | ≤ 30 ms p95 | 1.37 | 10.7 | 10.7 | 297 MB | 71 MB | – | tracked | [#209](https://github.com/storytold/photocraft/issues/209) |
| P51 | New layer in a 150-layer document | ≤ 16 ms p95 | 0.36 | 0.65 | 0.65 | 297 MB | 71 MB | – | tracked | [#1771](https://github.com/storytold/photocraft/issues/1771) |
| P13 | Brush dab on a 15000×10000 16-bit document | ≤ 80 ms p95 | 0.95 | 11.8 | 11.8 | 280 MB | 176 MB | – | tracked | [#209](https://github.com/storytold/photocraft/issues/209) |
| P14 | Move a layer on a 15000×10000 16-bit document | ≤ 80 ms p95 | 1.93 | 3.22 | 3.22 | 315 MB | 176 MB | – | tracked | [#209](https://github.com/storytold/photocraft/issues/209) |
| P16 | Brush dab on a 32-bit document with 20 layers | ≤ 100 ms p95 | 2.06 | 3.15 | 3.15 | 382 MB | 121 MB | – | tracked | [#209](https://github.com/storytold/photocraft/issues/209) |
| P17 | Move a layer on a 32-bit document with 20 layers | ≤ 100 ms p95 | 3.31 | 22.2 | 22.2 | 431 MB | 121 MB | – | tracked | [#209](https://github.com/storytold/photocraft/issues/209) |
| P18 | Open a 20 MP layered PSD: first pixels (today: fully opened) | ≤ 1000 ms p95 | 130 | 219 | 219 | 460 MB | 279 MB | – | tracked | [#210](https://github.com/storytold/photocraft/issues/210) |
| P19 | Open a 20 MP layered PSD: editable | ≤ 3000 ms p95 | 130 | 219 | 219 | 460 MB | 279 MB | – | tracked | [#210](https://github.com/storytold/photocraft/issues/210) |
| P20 | Open a 2 GB PSD: editable | opens with progress, editable, never blank | – | – | – | – | – | – | not run | [#210](https://github.com/storytold/photocraft/issues/210) |
| P63 | Open a 4–5 GB PSB: editable | opens with progress, editable, never blank | – | – | – | – | – | – | not run | [#210](https://github.com/storytold/photocraft/issues/210) |
| P21 | Content-Aware Fill on 10 MP | ≤ 1500 ms p95 | 169 | 176 | 176 | 486 MB | 270 MB | – | tracked | [#210](https://github.com/storytold/photocraft/issues/210) |
| P22 | Spot Healing stroke on 10 MP | ≤ 500 ms p95 | 97.8 | 109 | 109 | 481 MB | 216 MB | – | tracked | [#210](https://github.com/storytold/photocraft/issues/210) |
| P24 | Import 500 brushes (longest UI-thread step) | ≤ 100 ms max | 3.13 | 3.64 | 3.64 | 516 MB | 211 MB | – | tracked | [#210](https://github.com/storytold/photocraft/issues/210) |
| P25 | Cancel a Gaussian Blur job on 24 MP (until the worker exits) | ≤ 200 ms max | 0.27 | 6.15 | 6.15 | 565 MB | 211 MB | – | tracked | [#210](https://github.com/storytold/photocraft/issues/210) |
| P49 | Cancel a Content-Aware Fill job on 24 MP (until the worker exits) | ≤ 200 ms max | 1.18 | 4.72 | 4.72 | 522 MB | 211 MB | – | tracked | [#210](https://github.com/storytold/photocraft/issues/210) |
| P50 | App frame time while a 24 MP Gaussian Blur job runs | ≤ 16 ms p95 | 0.71 | 29.4 | 29.4 | 630 MB | 211 MB | – | tracked | [#210](https://github.com/storytold/photocraft/issues/210) |
| P26 | Select › Modify › Smooth on 24 MP (radius 50) | ≤ 100 ms p95 | 6.78 | 22.0 | 22.0 | 284 MB | – | – | tracked | [#211](https://github.com/storytold/photocraft/issues/211) |
| P27 | Select › Modify › Feather on 24 MP (radius 50) | ≤ 100 ms p95 | 6.06 | 21.8 | 21.8 | 296 MB | – | – | tracked | [#211](https://github.com/storytold/photocraft/issues/211) |
| P28 | Content-Aware Scale 24 MP (to 90 % width) | ≤ 3000 ms p95 | 386 | 386 | 386 | 396 MB | – | – | tracked | [#211](https://github.com/storytold/photocraft/issues/211) |
| P29 | Select Subject on 24 MP, repeated | ≤ 100 ms p95 | 0.22 | 0.23 | 0.23 | 317 MB | – | – | tracked | [#211](https://github.com/storytold/photocraft/issues/211) |
| P30 | Liquify 800 px brush on 3500×2200 at full resolution | ≤ 1 ms per update | 2.33 | 3.69 | 3.69 | 369 MB | – | – | tracked | [#211](https://github.com/storytold/photocraft/issues/211) |
| P31 | Camera Raw exposure change (proxy) | ≤ 10 ms | 8.50 | 25.8 | 25.8 | – | – | – | tracked | [#211](https://github.com/storytold/photocraft/issues/211) |
| P32 | Brush release on a long stroke | ≤ 16 ms (no hitch at mouse-up) | 1.33 | 15.8 | 15.8 | 393 MB | 93 MB | – | tracked | [#211](https://github.com/storytold/photocraft/issues/211) |
| P33 | Brush dab on A4 300 ppi CMYK (dab to screen) | ≤ 6 ms p95 | 1.10 | 1.95 | 1.95 | 385 MB | 86 MB | – | tracked | [#211](https://github.com/storytold/photocraft/issues/211) |
| P36 | Camera Raw exposure change with all SDR scopes (CPU) | ≤ 10 ms p95 | 16.6 | 32.6 | 32.6 | – | – | – | tracked | [#211](https://github.com/storytold/photocraft/issues/211) |
| P40 | Brush dab 60 px on 36 MP | track only | – | – | – | – | – | – | not run |  |
| P41 | Gaussian Blur r 40 on 36 MP | track only | – | – | – | – | – | – | not run |  |
| P42 | Curves dialog change, layer preview, 36 MP | track only | – | – | – | – | – | – | not run |  |
| P43 | Save .psd, 36 MP, 3 layers | track only | – | – | – | – | – | – | not run |  |
| P44 | Open .psd, 36 MP, 3 layers | track only | – | – | – | – | – | – | not run |  |
| P45 | Full refresh with layer effects, warm caches, 36 MP (GPU) | track only | – | – | – | – | – | – | not run |  |
| P46 | Brush dab on a layer with effects, 36 MP (GPU) | track only | – | – | – | – | – | – | not run |  |
| P47 | Font-size drag step, 50 type layers | track only | 4.49 | 24.2 | 24.2 | 76 MB | – | – | tracked |  |
| P48 | Full refresh of a 14000×14000 document | track only | – | – | – | – | – | – | not run |  |
| P52 | Chisel bevel size change, 12 MP ellipse, size 8 (GPU) | track only | 49.0 | 64.8 | 64.8 | 235 MB | – | – | tracked |  |
| P53 | Chisel bevel size change, 12 MP ellipse, size 50 (GPU) | track only | 71.0 | 72.3 | 72.3 | 280 MB | – | – | tracked |  |
| P54 | Chisel bevel size change, 12 MP ellipse, size 250 (GPU) | track only | 116 | 144 | 144 | 354 MB | – | – | tracked |  |
| P55 | Chisel bevel size change, 12 MP text paragraph, size 8 (GPU) | track only | 49.1 | 63.6 | 63.6 | 403 MB | – | – | tracked |  |
| P56 | Chisel bevel size change, 12 MP text paragraph, size 50 (GPU) | track only | 55.2 | 64.3 | 64.3 | 443 MB | – | – | tracked |  |
| P57 | Chisel bevel size change, 12 MP text paragraph, size 250 (GPU) | track only | 125 | 132 | 132 | 516 MB | – | – | tracked |  |
| P58 | Chisel bevel size change, 12 MP ellipse, size 8 (CPU) | track only | 76.1 | 76.8 | 76.8 | 235 MB | – | – | tracked |  |
| P59 | Chisel bevel size change, 12 MP text paragraph, size 8 (CPU) | track only | 62.8 | 77.4 | 77.4 | 403 MB | – | – | tracked |  |
| P60 | Layer opacity among 150 full-canvas layers, 6 MP (app GPU budget) | ≤ 30 ms p95 | 0.51 | 1.20 | 1.20 | 329 MB | 96 MB | – | tracked | [#5973](https://github.com/storytold/photocraft/issues/5973) |
| P61 | Hide a layer among 150 full-canvas layers, 6 MP (app GPU budget) | ≤ 30 ms p95 | 0.46 | 0.50 | 0.50 | 329 MB | 96 MB | – | tracked | [#5973](https://github.com/storytold/photocraft/issues/5973) |
| P62 | File > New 10 x 5 m at 200 ppi (3.1 GP) + first reduced canvas refresh | track only | 50.0 | 51.9 | 51.9 | 436 MB | – | – | tracked | [#4017](https://github.com/storytold/photocraft/issues/4017) |
| P64 | Oil Paint on 24 MP | ≤ 1000 ms p95 | 143 | 143 | 143 | – | – | – | tracked | [#211](https://github.com/storytold/photocraft/issues/211) |
| P65 | Smart Blur r 12 on 24 MP (High quality) | ≤ 1000 ms p95 | 136 | 136 | 136 | – | – | – | tracked | [#211](https://github.com/storytold/photocraft/issues/211) |
| P66 | Relight on 24 MP | ≤ 1000 ms p95 | 71.2 | 71.2 | 71.2 | – | – | – | tracked | [#211](https://github.com/storytold/photocraft/issues/211) |
| P67 | Reduce Noise on 24 MP | ≤ 1000 ms p95 | 80.4 | 80.4 | 80.4 | – | – | – | tracked | [#211](https://github.com/storytold/photocraft/issues/211) |

**Not measurable yet** (the code can't do it yet; no number is recorded):

| Id | Scenario | Target | Why | Issue |
|---|---|---|---|---|
| P15 | Zoom / pan frame time on a 15000×10000 16-bit document | ≤ 16 ms per frame | no headless canvas frame harness yet (zoom and pan sample the GPU texture in the egui paint callback) | [#209](https://github.com/storytold/photocraft/issues/209) |
| P23 | Warp / Puppet / Perspective preview at 4K | ≤ 16 ms per frame, commit in the background | the previews run inside the UI tools; no headless frame harness, no background commit | [#210](https://github.com/storytold/photocraft/issues/210) |
| P34 | Brush preview memory, small dab on an 8K viewport | ≤ 2 MiB | the live brush preview buffers are UI-side; no headless counter yet | [#211](https://github.com/storytold/photocraft/issues/211) |
| P35 | Marquee drag on 24 MP with Alt/Shift | ≤ 17 ms p95 | Shift/Alt marquee modifiers don't exist yet (#208) and the drag preview is UI-side | [#211](https://github.com/storytold/photocraft/issues/211) |
