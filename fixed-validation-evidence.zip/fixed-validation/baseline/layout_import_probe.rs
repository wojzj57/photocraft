// Isolated diagnostic against the archived base commit; not production code.
#[path = "../../ui-egui/tests/support/layout_doc.rs"]
mod layout_doc;

use photocraft_engine::Session;
use serde_json::json;

fn main() {
    let (doc, _) = layout_doc::build(layout_doc::Spec::full());
    let psd = photocraft_io::export(&doc, "layout.psd", &Default::default())
        .expect("baseline layout PSD export")
        .bytes;
    let imported = photocraft_io::import("layout.psd", &psd).expect("baseline layout PSD import");
    let mut session = Session::new();
    session.open_document(imported.document, None);
    let ids: Vec<u64> = session
        .active()
        .map(|st| {
            st.doc
                .walk()
                .iter()
                .filter(|(_, _, l)| {
                    l.name == "Logo"
                        || (l.name.starts_with("Product ")
                            && !l.name.contains('\u{2014}')
                            && !l.is_group())
                })
                .map(|(_, _, l)| l.id.0)
                .collect()
        })
        .unwrap_or_default();
    println!("baseline layout convert candidates: {}", ids.len());
    for id in ids {
        match session.execute("layer.smartObjects.convertToSmartObject", json!({ "layer": id })) {
            Ok(_) => {}
            Err(error) => {
                println!("BASELINE_LAYOUT_REPRODUCED id={id} error={error}");
                return;
            }
        }
    }
    panic!("baseline layout did not reproduce smart object conversion failure");
}
